
# Copilot SDK Multi‑Agent Demo

This project demonstrates a simple **multi‑agent AI development workflow** using the **GitHub Copilot SDK**.

Agents included:

• Code Agent – generates application code from a specification  
• Test Agent – generates unit tests for the generated code  
• Orchestrator – coordinates communication between agents  

Architecture:

User Spec → Code Agent → Test Agent → Result

---

## Project Structure

copilot-sdk-demo
│
├── agents
│   ├── codeAgent.js
│   └── testAgent.js
│
├── services
│   └── orchestrator.js
│
├── routes
│   └── generateService.js
│
├── server.js
├── package.json
└── README.md

---

## Installation

1. Install Node.js (v18+ recommended)

2. Install dependencies

npm install

---

## Run the Application

node server.js

Server starts on:

http://localhost:3000

---

## API Usage

POST /api/generate

Example request:

{
  "spec": "Create a Spring Boot REST API for Employee CRUD operations"
}

Example response:

{
  "code": "...generated controller/service code...",
  "tests": "...generated junit tests..."
}

---

## Demo Flow

1. User sends specification
2. Code Agent generates application code
3. Test Agent generates test cases
4. Orchestrator returns the result

---

## Demo Idea for Teams

You can demonstrate:

Specification → AI Code Generation → AI Test Generation

This shows how **Copilot SDK can orchestrate multiple AI agents for automated software development workflows**.

---

## Possible Extensions

• Add Security Agent (fix vulnerabilities)  
• Add Build Agent (run Maven build)  
• Add Fix Agent (auto‑fix failing tests)  
• Connect to GitHub repo to create PR automatically

---

Author: Copilot SDK Demo
