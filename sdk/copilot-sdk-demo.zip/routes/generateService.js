
import express from "express"
import { runPipeline } from "../services/orchestrator.js"

const router = express.Router()

router.post("/generate", async (req, res) => {

  const spec = req.body.spec

  try {
    const result = await runPipeline(spec)
    res.json(result)
  } catch (err) {
    res.status(500).json({ error: err.message })
  }

})

export default router
