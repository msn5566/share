
import { CopilotAgent } from "@github/copilot-sdk"

export async function generateCode(spec) {

  const agent = new CopilotAgent({
    name: "code-agent",
    description: "Generate code from specification"
  })

  const result = await agent.run({
    task: `Generate Java Spring Boot code for: ${spec}`
  })

  return result
}
