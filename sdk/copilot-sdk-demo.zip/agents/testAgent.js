
import { CopilotAgent } from "@github/copilot-sdk"

export async function generateTests(code) {

  const agent = new CopilotAgent({
    name: "test-agent"
  })

  const tests = await agent.run({
    task: `Generate JUnit tests for the following code:\n${code}`
  })

  return tests
}
