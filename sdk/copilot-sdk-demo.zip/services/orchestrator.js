
import { generateCode } from "../agents/codeAgent.js"
import { generateTests } from "../agents/testAgent.js"

export async function runPipeline(spec) {

  const code = await generateCode(spec)

  const tests = await generateTests(code)

  return {
    code,
    tests
  }
}
