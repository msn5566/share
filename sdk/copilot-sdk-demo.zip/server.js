
import express from "express"
import generateRoute from "./routes/generateService.js"

const app = express()

app.use(express.json())

app.use("/api", generateRoute)

app.listen(3000, () => {
  console.log("AI Dev Platform running on port 3000")
})
