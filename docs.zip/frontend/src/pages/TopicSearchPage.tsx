import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { runPipeline } from '../services/api';

const TopicSearchPage: React.FC = () => {
  const [topic, setTopic] = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleSearch = async () => {
    setLoading(true);
    await runPipeline(topic);
    setLoading(false);
    navigate('/results', { state: { topic } });
  };

  return (
    <div style={{ maxWidth: 600, margin: 'auto', padding: 32 }}>
      <h2>Search Topic</h2>
      <input type="text" value={topic} onChange={e => setTopic(e.target.value)} placeholder="Enter topic" />
      <button onClick={handleSearch} disabled={loading || !topic}>Run Pipeline</button>
      {loading && <div>Loading...</div>}
    </div>
  );
};

export default TopicSearchPage;
