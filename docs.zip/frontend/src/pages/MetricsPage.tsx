import React from 'react';
import TitledSection from '../components/TitledSection';

const MetricsPage: React.FC = () => (
  <div style={{ maxWidth: 600, margin: 'auto', padding: 32 }}>
    <TitledSection title="Summarization Metrics">
      <ul>
        <li>ROUGE Score: Placeholder</li>
        <li>BERTScore: Placeholder</li>
      </ul>
    </TitledSection>
    <TitledSection title="Novelty Scoring">
      <ul>
        <li>Novelty: Placeholder</li>
      </ul>
    </TitledSection>
    <TitledSection title="Pipeline Performance">
      <ul>
        <li>Execution Time: Placeholder</li>
      </ul>
    </TitledSection>
  </div>
);

export default MetricsPage;
