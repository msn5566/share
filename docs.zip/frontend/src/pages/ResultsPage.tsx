import React, { useEffect, useState } from 'react';
import { useLocation } from 'react-router-dom';
import { getHypotheses } from '../services/api';
import SummaryCard from '../components/SummaryCard';
import HypothesisCard from '../components/HypothesisCard';
import TitledSection from '../components/TitledSection';

const ResultsPage: React.FC = () => {
  const location = useLocation();
  const topic = location.state?.topic || '';
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (topic) {
      getHypotheses(topic).then(res => {
        setData(res);
        setLoading(false);
      });
    }
  }, [topic]);

  if (loading) return <div>Loading...</div>;
  if (!data) return <div>No data found.</div>;

  return (
    <div style={{ maxWidth: 900, margin: 'auto', padding: 32 }}>
      <TitledSection title="Hypotheses">
        {data.hypotheses?.map((h: string, i: number) => <HypothesisCard key={i} hypothesis={h} />)}
      </TitledSection>
      <TitledSection title="Summaries">
        {data.summaries?.map((s: any, i: number) => <SummaryCard key={i} summary={s.summary} />)}
      </TitledSection>
      <TitledSection title="Insights">
        <pre style={{ background: '#f4f4f4', padding: 16 }}>{JSON.stringify(data.insights, null, 2)}</pre>
      </TitledSection>
    </div>
  );
};

export default ResultsPage;
