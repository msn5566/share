export async function runPipeline(topic: string) {
  const res = await fetch('http://localhost:8000/pipeline/run', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ topic })
  });
  if (!res.ok) throw new Error('Pipeline error');
  return await res.json();
}

export async function getHypotheses(topic: string) {
  const res = await fetch(`http://localhost:8000/hypotheses/${topic}`);
  if (!res.ok) throw new Error('No hypotheses found');
  return await res.json();
}
