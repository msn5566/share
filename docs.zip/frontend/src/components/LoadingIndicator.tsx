import React from 'react';

const LoadingIndicator: React.FC = () => (
  <div style={{ textAlign: 'center', padding: 32 }}>
    <span>Loading...</span>
  </div>
);

export default LoadingIndicator;
