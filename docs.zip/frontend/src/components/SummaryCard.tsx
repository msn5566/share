import React from 'react';

const SummaryCard: React.FC<{ summary: string }> = ({ summary }) => (
  <div style={{ border: '1px solid #ccc', borderRadius: 8, padding: 16, marginBottom: 12 }}>
    <strong>Summary:</strong>
    <div>{summary}</div>
  </div>
);

export default SummaryCard;
