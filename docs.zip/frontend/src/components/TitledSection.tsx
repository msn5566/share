import React from 'react';

const TitledSection: React.FC<{ title: string; children: React.ReactNode }> = ({ title, children }) => (
  <section style={{ marginBottom: 32 }}>
    <h3 style={{ borderBottom: '1px solid #ddd', paddingBottom: 8 }}>{title}</h3>
    {children}
  </section>
);

export default TitledSection;
