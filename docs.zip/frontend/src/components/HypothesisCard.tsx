import React from 'react';

const HypothesisCard: React.FC<{ hypothesis: string }> = ({ hypothesis }) => (
  <div style={{ border: '1px solid #0077cc', borderRadius: 8, padding: 16, marginBottom: 12, background: '#e6f7ff' }}>
    <strong>Hypothesis:</strong>
    <div>{hypothesis}</div>
  </div>
);

export default HypothesisCard;
