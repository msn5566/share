import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import LoginPage from './pages/LoginPage';
import TopicSearchPage from './pages/TopicSearchPage';
import ResultsPage from './pages/ResultsPage';
import MetricsPage from './pages/MetricsPage';

const App: React.FC = () => (
  <BrowserRouter>
    <Routes>
      <Route path="/" element={<LoginPage />} />
      <Route path="/search" element={<TopicSearchPage />} />
      <Route path="/results" element={<ResultsPage />} />
      <Route path="/metrics" element={<MetricsPage />} />
    </Routes>
  </BrowserRouter>
);

export default App;
