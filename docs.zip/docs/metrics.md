# Metrics

## Summarization Metrics
- ROUGE Score (placeholder)
- BERTScore (placeholder)

## Novelty Scoring
- Compare generated hypotheses to existing literature
- Score based on uniqueness (logic placeholder)

## Pipeline Performance
- Measure execution time per agent
- Track number of papers processed
