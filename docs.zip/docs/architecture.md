# Architecture

## Frontend
- React (Vite + TypeScript)
- Pages: Login/Register, Topic Search, Results, Metrics
- Components: SummaryCard, HypothesisCard, LoadingIndicator, TitledSection
- Services: api.ts, auth.ts

## Backend
- FastAPI
- Agents: summarizer, insight, hypothesis, orchestrator
- Services: PubMed API, file storage, auth
- Routes: papers_api, auth_api, main

## Agent Workflow Diagram
```
[User] -> [Pipeline Orchestrator] -> [Retrieval Agent] -> [Summarizer Agent] -> [Insight Agent] -> [Hypothesis Agent]
```

## File-System Data Layout
- /storage/users/{username}.json
- /storage/papers/{paper_id}.json
- /storage/summaries/{paper_id}.json
- /storage/hypotheses/{topic}.json
