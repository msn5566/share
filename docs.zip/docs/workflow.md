# Workflow

## Pipeline Execution
1. User enters topic
2. Orchestrator triggers PubMed retrieval
3. Summarizer agent summarizes abstracts
4. Insight agent extracts entities/relationships
5. Hypothesis agent generates hypotheses
6. Results saved to file system

## Agent Interactions
- Orchestrator calls agents in sequence
- Each agent saves output to /storage

## PubMed API Call Flow
- Search papers by topic
- Fetch paper details by ID
