# API Spec

## POST /auth/register
- Request: { username, password }
- Response: { success }

## POST /auth/login
- Request: { username, password }
- Response: { success }

## GET /papers/search?topic=
- Response: { papers: [ { paper_id, title, abstract } ] }

## POST /pipeline/run
- Request: { topic }
- Response: { summaries, insights, hypotheses }

## GET /hypotheses/{topic}
- Response: { topic, hypotheses }
