# Life Sciences Paper Summarization & Hypothesis Generator

A full-stack multi-agent AI system for summarizing life sciences papers and generating hypotheses.

## Features
- FastAPI backend with multi-agent pipeline
- React frontend (Vite + TypeScript)
- PubMed API integration
- File-system JSON storage (no database)
- User authentication

## Quickstart

### Backend
```sh
cd backend
pip install -r requirements.txt
uvicorn routes.main:app --reload
```

### Frontend
```sh
cd frontend
npm install
npm run dev
```

## Storage Layout
- `/storage/users/{username}.json` — user data
- `/storage/papers/{paper_id}.json` — raw papers
- `/storage/summaries/{paper_id}.json` — summaries/insights
- `/storage/hypotheses/{topic}.json` — generated hypotheses

## Docs
See `/docs` for architecture, workflow, metrics, and API spec.
