import os
import json
from typing import Dict
from transformers import pipeline
from ..services.file_storage_service import write_json

class SummarizerAgent:
    def __init__(self):
        self.summarizer = pipeline('summarization', model='facebook/bart-large-cnn')

    def summarize(self, paper_id: str, text: str) -> Dict:
        summary = self.summarizer(text, max_length=200, min_length=50, do_sample=False)[0]['summary_text']
        summary_data = {
            'paper_id': paper_id,
            'summary': summary
        }
        write_json(f'storage/summaries/{paper_id}.json', summary_data)
        return summary_data
