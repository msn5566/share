import re
from typing import Dict, List
from ..services.file_storage_service import write_json

class InsightAgent:
    def extract_insights(self, paper_id: str, text: str) -> Dict:
        # Dummy biological entity extraction
        entities = re.findall(r'\b([A-Z][a-zA-Z0-9]+)\b', text)
        pathways = [e for e in entities if 'ase' in e or 'pathway' in e]
        relationships = [(entities[i], entities[i+1]) for i in range(len(entities)-1)]
        insights = {
            'paper_id': paper_id,
            'entities': entities,
            'pathways': pathways,
            'relationships': relationships
        }
        write_json(f'storage/summaries/{paper_id}.json', insights)
        return insights
