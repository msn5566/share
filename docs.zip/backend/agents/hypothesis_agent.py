from typing import Dict, List
from ..services.file_storage_service import write_json

class HypothesisAgent:
    def generate_hypotheses(self, topic: str, insights_list: List[Dict]) -> Dict:
        # Dummy hypothesis generation
        hypotheses = [
            f"If {insight['entities'][0]} is involved in {insight['pathways'][0]}, then it may affect {topic}."
            for insight in insights_list if insight['entities'] and insight['pathways']
        ]
        result = {
            'topic': topic,
            'hypotheses': hypotheses
        }
        write_json(f'storage/hypotheses/{topic}.json', result)
        return result
