from .summarizer_agent import SummarizerAgent
from .insight_agent import InsightAgent
from .hypothesis_agent import HypothesisAgent
from ..services.pubmed_service import PubMedService
from ..services.file_storage_service import read_json, write_json
import os

class PipelineOrchestrator:
    def __init__(self):
        self.pubmed = PubMedService()
        self.summarizer = SummarizerAgent()
        self.insight = InsightAgent()
        self.hypothesis = HypothesisAgent()

    def run_pipeline(self, topic: str):
        paper_ids = self.pubmed.search_papers(topic)
        summaries = []
        insights_list = []
        for paper_id in paper_ids:
            paper = self.pubmed.fetch_paper(paper_id)
            write_json(f'storage/papers/{paper_id}.json', paper)
            summary = self.summarizer.summarize(paper_id, paper['abstract'])
            summaries.append(summary)
            insights = self.insight.extract_insights(paper_id, paper['abstract'])
            insights_list.append(insights)
        hypotheses = self.hypothesis.generate_hypotheses(topic, insights_list)
        return {
            'summaries': summaries,
            'insights': insights_list,
            'hypotheses': hypotheses
        }
