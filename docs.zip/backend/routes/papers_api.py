from fastapi import APIRouter, Query
from ..services.pubmed_service import PubMedService
from ..services.file_storage_service import read_all_json

router = APIRouter()

@router.get('/papers/search')
def search_papers(topic: str = Query(...)):
    pubmed = PubMedService()
    paper_ids = pubmed.search_papers(topic)
    papers = [pubmed.fetch_paper(pid) for pid in paper_ids]
    return {'papers': papers}
