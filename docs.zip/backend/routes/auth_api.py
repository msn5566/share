from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from ..services.auth_service import register_user, validate_user

router = APIRouter()

class RegisterRequest(BaseModel):
    username: str
    password: str

@router.post('/auth/register')
def register(data: RegisterRequest):
    if not register_user(data.username, data.password):
        raise HTTPException(status_code=400, detail='User already exists')
    return {'success': True}

class LoginRequest(BaseModel):
    username: str
    password: str

@router.post('/auth/login')
def login(data: LoginRequest):
    if not validate_user(data.username, data.password):
        raise HTTPException(status_code=401, detail='Invalid credentials')
    return {'success': True}
