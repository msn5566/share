from fastapi import FastAPI, Request, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from .papers_api import router as papers_router
from .auth_api import router as auth_router
from ..agents.pipeline_orchestrator import PipelineOrchestrator
from ..services.file_storage_service import read_json
import os

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(papers_router)
app.include_router(auth_router)

@app.post('/pipeline/run')
async def run_pipeline(request: Request):
    data = await request.json()
    topic = data.get('topic')
    if not topic:
        raise HTTPException(status_code=400, detail='Topic required')
    orchestrator = PipelineOrchestrator()
    result = orchestrator.run_pipeline(topic)
    return result

@app.get('/hypotheses/{topic}')
def get_hypotheses(topic: str):
    path = f'storage/hypotheses/{topic}.json'
    if not os.path.exists(path):
        raise HTTPException(status_code=404, detail='No hypotheses found')
    return read_json(path)
