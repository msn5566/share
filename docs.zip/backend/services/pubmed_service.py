import requests
from typing import List, Dict

class PubMedService:
    BASE_URL = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/"

    def search_papers(self, topic: str) -> List[str]:
        params = {
            'db': 'pubmed',
            'term': topic,
            'retmax': 5,
            'retmode': 'json'
        }
        resp = requests.get(self.BASE_URL + 'esearch.fcgi', params=params)
        data = resp.json()
        return data.get('esearchresult', {}).get('idlist', [])

    def fetch_paper(self, paper_id: str) -> Dict:
        params = {
            'db': 'pubmed',
            'id': paper_id,
            'retmode': 'xml'
        }
        resp = requests.get(self.BASE_URL + 'efetch.fcgi', params=params)
        # Parse XML for title/abstract (simple parsing)
        import xml.etree.ElementTree as ET
        root = ET.fromstring(resp.text)
        article = root.find('.//Article')
        title = article.findtext('.//ArticleTitle') if article is not None else ''
        abstract = article.findtext('.//AbstractText') if article is not None else ''
        return {'paper_id': paper_id, 'title': title, 'abstract': abstract}
