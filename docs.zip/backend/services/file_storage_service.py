import os
import json
from typing import Any, Dict, List

def ensure_dirs():
    os.makedirs('storage/users', exist_ok=True)
    os.makedirs('storage/papers', exist_ok=True)
    os.makedirs('storage/summaries', exist_ok=True)
    os.makedirs('storage/hypotheses', exist_ok=True)

def write_json(path: str, data: Any):
    ensure_dirs()
    with open(path, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=2)

def read_json(path: str) -> Any:
    with open(path, 'r', encoding='utf-8') as f:
        return json.load(f)

def read_all_json(folder: str) -> List[Dict]:
    ensure_dirs()
    results = []
    for filename in os.listdir(folder):
        if filename.endswith('.json'):
            with open(os.path.join(folder, filename), 'r', encoding='utf-8') as f:
                results.append(json.load(f))
    return results
