import os
import json
import hashlib
from backend.services.file_storage_service import write_json, read_json, ensure_dirs

def hash_password(password: str) -> str:
    return hashlib.sha256(password.encode()).hexdigest()

def register_user(username: str, password: str) -> bool:
    ensure_dirs()
    user_path = f'storage/users/{username}.json'
    if os.path.exists(user_path):
        return False
    user = {
        'username': username,
        'password_hash': hash_password(password)
    }
    write_json(user_path, user)
    return True

def validate_user(username: str, password: str) -> bool:
    user_path = f'storage/users/{username}.json'
    if not os.path.exists(user_path):
        return False
    user = read_json(user_path)
    return user['password_hash'] == hash_password(password)
